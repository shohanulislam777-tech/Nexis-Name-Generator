@echo off
set "files=background.js pageHook.js hwFingerprint.js sounds.js i18n.js content-templates.js content.js license-fix.js sidepanel.js sidepanel-templates.js"

for %%f in (%files%) do (
    echo Obfuscating %%f...
    call npx -y javascript-obfuscator "%%f" -o "%%f"
)
echo All files obfuscated successfully!
