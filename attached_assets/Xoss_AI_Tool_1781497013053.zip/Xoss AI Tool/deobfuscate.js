// Deobfuscator for pageHook.js
// Step 1: Extract and decode the string table

const fs = require('fs');
const code = fs.readFileSync(__dirname + '/pageHook.js', 'utf-8');

// Extract the string array from _0x21aa function
const arrayMatch = code.match(/const\s+_0x41c77f\s*=\s*\[([^\]]+)\]/);
if (!arrayMatch) { console.error("Could not find string array"); process.exit(1); }

// Parse the array
let strings = [];
const raw = arrayMatch[1];
const parts = raw.match(/'[^']*'/g);
parts.forEach(p => strings.push(p.slice(1, -1)));

console.log("=== STRING TABLE (" + strings.length + " entries) ===\n");

// Decode function - same as _0x50a0's GXcitC
function decode(encoded) {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';
    let result = '', temp = '';
    for (let i = 0, a, b, c = 0; b = encoded.charAt(c++); ~b && (a = i % 4 ? a * 64 + b : b, i++ % 4) ? result += String.fromCharCode(255 & a >> (-2 * i & 6)) : 0) {
        b = chars.indexOf(b);
    }
    for (let i = 0; i < result.length; i++) {
        temp += '%' + ('00' + result.charCodeAt(i).toString(16)).slice(-2);
    }
    return decodeURIComponent(temp);
}

// Now we need to find the correct rotation of the array
// The shuffle IIFE rotates the array until a checksum matches 0x187da (99290)
const targetChecksum = 0x187da;

// The _0x50a0 function: index = arg - 0x1a3, then returns decoded strings[index]
// But we need to first do the shuffle

// Try all rotations (max = array length)
let foundRotation = -1;

// Clone original array for rotation attempts
const originalStrings = [...strings];

// The checksum is computed from parseInt of decoded strings at specific indices
// Since the shuffle IIFE is complex, let's just try rotating and see

// Alternative approach: just decode ALL strings and show them
console.log("=== ALL DECODED STRINGS ===\n");
const decoded = [];
for (let i = 0; i < strings.length; i++) {
    try {
        const d = decode(strings[i]);
        decoded.push({ index: i, encoded: strings[i], decoded: d });
    } catch(e) {
        decoded.push({ index: i, encoded: strings[i], decoded: "[DECODE ERROR]" });
    }
}

// Group by category for analysis
const categories = {
    'DOM/Window APIs': [],
    'WebSocket related': [],
    'Fetch/XHR related': [],
    'Token/Auth related': [],
    'Message/Event related': [],
    'String methods': [],
    'Other': []
};

decoded.forEach(item => {
    const d = item.decoded.toLowerCase();
    if (d.includes('websocket') || d.includes('readystate') || d.includes('onmessage') || d.includes('onopen') || d.includes('send') || d.includes('ws')) {
        categories['WebSocket related'].push(item);
    } else if (d.includes('fetch') || d.includes('xhr') || d.includes('request') || d.includes('response') || d.includes('header')) {
        categories['Fetch/XHR related'].push(item);
    } else if (d.includes('token') || d.includes('auth') || d.includes('bearer') || d.includes('cookie') || d.includes('credential') || d.includes('session')) {
        categories['Token/Auth related'].push(item);
    } else if (d.includes('message') || d.includes('event') || d.includes('listener') || d.includes('dispatch') || d.includes('postmessage')) {
        categories['Message/Event related'].push(item);
    } else if (d.includes('document') || d.includes('window') || d.includes('element') || d.includes('queryselector') || d.includes('getitem') || d.includes('setitem') || d.includes('localstorage')) {
        categories['DOM/Window APIs'].push(item);
    } else if (d.includes('replace') || d.includes('match') || d.includes('split') || d.includes('substr') || d.includes('indexof') || d.includes('concat') || d.includes('join') || d.includes('trim') || d.includes('slice')) {
        categories['String methods'].push(item);
    } else {
        categories['Other'].push(item);
    }
});

Object.keys(categories).forEach(cat => {
    if (categories[cat].length === 0) return;
    console.log("\n--- " + cat + " (" + categories[cat].length + ") ---");
    categories[cat].forEach(item => {
        console.log(`  [${item.index}] "${item.decoded}"`);
    });
});

// Also output full table for reference
console.log("\n\n=== COMPLETE STRING TABLE (sorted by index) ===\n");
decoded.forEach(item => {
    console.log(`  [${String(item.index).padStart(3)}] ${item.encoded.padEnd(20)} → "${item.decoded}"`);
});

// Now look for specific patterns in the raw code
console.log("\n\n=== CODE PATTERN ANALYSIS ===\n");

// Find WebSocket constructor override
if (code.includes('WebSocket')) {
    console.log("✅ WebSocket reference found - likely hooks WebSocket");
}

// Find postMessage calls
const postMsgCount = (code.match(/postMessage/g) || []).length;
console.log(`✅ postMessage references: ${postMsgCount}`);

// Find readyState
if (code.includes('readyState') || code.includes('OPEN')) {
    console.log("✅ WebSocket readyState/OPEN check found");
}

// Check for fetch/XHR override
if (code.includes('prototype')) {
    console.log("✅ prototype access found - may override native APIs");
}

// Find regex patterns (readable even in obfuscated code)
const regexMatches = code.match(/\/[^\/\n]+\/[gimsuvy]*/g) || [];
console.log(`\n--- Regex patterns found (${regexMatches.length}) ---`);
regexMatches.forEach(r => console.log("  " + r));
